.. _testimonials:

================================================================================
Who is using scikit-learn?
================================================================================

.. raw:: html

  <div class="testimonial">


.. to add a testimonials, just XXX


Inria
-------------------------------

.. image:: images/inria.jpg

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus et ipsum ac
ipsum auctor pulvinar. In fermentum justo libero, in aliquet dui tempus sit
amet. Maecenas sed sem purus. Nulla mollis mi sit amet diam tristique, vitae
accumsan tellus ullamcorper. Pellentesque ligula est, molestie non eros sed,
sodales aliquam quam.

.. raw:: html

   <div class="testimonial-website">

**website:** `www.inria.fr <http://www.inria.fr>`_

.. raw:: html

    </div>


Inria
-------------------------------

.. image:: images/inria.jpg

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus et ipsum ac
ipsum auctor pulvinar. In fermentum justo libero, in aliquet dui tempus sit
amet. Maecenas sed sem purus. Nulla mollis mi sit amet diam tristique, vitae
accumsan tellus ullamcorper. Pellentesque ligula est, molestie non eros sed,
sodales aliquam quam.

.. raw:: html

   <div class="testimonial-website">

**website:** `www.inria.fr <http://www.inria.fr>`_

.. raw:: html

    </div>


.. END

.. raw:: html

    </div>
